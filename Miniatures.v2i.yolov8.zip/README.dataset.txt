# Miniatures > 2025-07-12 3:08pm
https://universe.roboflow.com/gustavo-workspace/miniatures-qqawf

Provided by a Roboflow user
License: CC BY 4.0

